import { HomeComponent } from "../Home/testBOMApp.HomeComponent";
import { ProjectComponent } from "../Project/testBOMApp.ProjectComponent";
import { ClusterComponent } from "../Cluster/testBOMApp.ClusterComponent";
import { DeviceComponent } from "../Device/testBOMApp.DeviceComponent";
import { DiskComponent } from "../Disk/testBOMApp.DiskComponent";

export const MainRoutes = [
    { path: 'Home', component: HomeComponent },
    { path: 'Project', component: ProjectComponent },
    { path: 'Cluster', component: ClusterComponent },
    { path: 'Device', component: DeviceComponent },
    { path: 'Disk', component: DiskComponent },
    { path: '', component: HomeComponent }    
];