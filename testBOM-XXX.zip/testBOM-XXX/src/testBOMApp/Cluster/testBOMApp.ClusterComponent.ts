import { Component } from '@angular/core';
@Component({
  templateUrl: './testBOMApp.ClusterView.html'
})
export class ClusterComponent {
  
}