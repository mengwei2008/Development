import { Component } from '@angular/core';
import {Project} from "./testBOMApp.ProjectModel"
@Component({
  templateUrl: './testBOMApp.ProjectView.html'
})
export  class ProjectComponent {
  title = 'testBOMApplication';
  ProjectModel : Project = new Project();
  ProjectModels:Array<Project> = new Array<Project>();
  Add(){
    this.ProjectModels.push(this.ProjectModel);
    this.ProjectModel = new Project();// clear UI
  }
}