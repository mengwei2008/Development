export class Project{
    ProjectNme:string = "";
    ClusterCode:string = "";
}