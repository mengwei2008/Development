import { Component } from '@angular/core';
@Component({
  selector: 'myapp-root',
  templateUrl: './testBOMApp.MasterPageView.html'
})
export class MasterPageComponent {
  
}