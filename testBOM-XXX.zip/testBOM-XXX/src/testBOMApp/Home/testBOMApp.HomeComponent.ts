import { Component } from '@angular/core';
@Component({
  templateUrl: './testBOMApp.HomeView.html'
})
export  class HomeComponent {
  title = 'testBOMApplication';
}