import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule} from "@angular/forms"
import { RouterModule} from "@angular/router"
import { MasterPageComponent } from './Home/testBOMApp.MasterPageComponent'
import { HomeComponent } from './Home/testBOMApp.HomeComponent'
import { ProjectComponent } from './Project/testBOMApp.ProjectComponent'
import { ClusterComponent } from './Cluster/testBOMApp.ClusterComponent'
import { DeviceComponent } from './Device/testBOMApp.DeviceComponent'
import { DiskComponent } from './Disk/testBOMApp.DiskComponent'
import { MainRoutes } from './Routing/testBOMApp.MainRouting'
@NgModule({
  declarations: [
    MasterPageComponent,
    HomeComponent, 
    ProjectComponent, 
    ClusterComponent, 
    DeviceComponent,
    DiskComponent
  ],
  imports: [
    RouterModule.forRoot(MainRoutes),
    BrowserModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [MasterPageComponent]
})
export class testBOMProjectModule {

}