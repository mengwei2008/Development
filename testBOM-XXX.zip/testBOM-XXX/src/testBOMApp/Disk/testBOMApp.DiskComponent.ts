import { Component } from '@angular/core';
@Component({
  templateUrl: './testBOMApp.DiskView.html'
})
export  class DiskComponent {
  
}