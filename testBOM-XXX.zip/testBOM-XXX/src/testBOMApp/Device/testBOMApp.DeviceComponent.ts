import { Component } from '@angular/core';
@Component({
  templateUrl: './testBOMApp.DeviceView.html'
})
export class DeviceComponent {
  
}
